# Drops POS Android v0.1
Native Android prototype. Offline local data via SharedPreferences.
Test flow: add demo Floor Cleaner 4L (10 units, $3.50), then sell 2; stock becomes 8 and sales $7.
GitHub Actions workflow builds a debug APK using JDK 17, Gradle 9.6 and AGP 9.4.
Next: SQLite/Room-style database layer, products, POS, customers/debts, raw materials, formulas/BOM, batches, expenses, backup.
