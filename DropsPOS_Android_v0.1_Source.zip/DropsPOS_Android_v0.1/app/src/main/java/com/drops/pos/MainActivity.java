package com.drops.pos;
import android.app.Activity;import android.os.Bundle;import android.content.SharedPreferences;import android.widget.*;
public class MainActivity extends Activity {
 SharedPreferences p; TextView summary,log;
 int stock(){return p.getInt("stock",0);} float sales(){return p.getFloat("sales",0f);}
 void render(){summary.setText("المخزون: "+stock()+" غالون\nالمبيعات: $"+String.format("%.2f",sales()));}
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(com.drops.pos.R.layout.activity_main);p=getSharedPreferences("drops",MODE_PRIVATE);summary=findViewById(R.id.summary);log=findViewById(R.id.log);render();
 findViewById(R.id.addDemo).setOnClickListener(v->{p.edit().putInt("stock",10).apply();log.setText("تم إنشاء Floor Cleaner 4L — السعر $3.50 — الرصيد 10");render();});
 findViewById(R.id.sellDemo).setOnClickListener(v->{if(stock()<2){Toast.makeText(this,"المخزون غير كافٍ",Toast.LENGTH_SHORT).show();return;}p.edit().putInt("stock",stock()-2).putFloat("sales",sales()+7f).apply();log.setText("تم بيع 2 × $3.50. السعر سُحب تلقائياً. الرصيد الجديد: "+stock());render();});
 }
}
