plugins { id("com.android.application") }
android {
 namespace = "com.drops.pos"
 compileSdk = 37
 defaultConfig { applicationId = "com.drops.pos"; minSdk = 26; targetSdk = 37; versionCode = 1; versionName = "0.1.0" }
}
